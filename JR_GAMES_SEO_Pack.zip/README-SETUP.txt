JR GAMES SEO SETUP

1. Add the contents of seo-head-tags.txt inside the <head> section of index.html.
2. Upload robots.txt and sitemap.xml to the ROOT of the GitHub repository (same level as index.html).
3. Publish GitHub Pages and test these URLs:
   https://jibonjr5426-cmd.github.io/Jr-games/robots.txt
   https://jibonjr5426-cmd.github.io/Jr-games/sitemap.xml
4. Open Google Search Console: https://search.google.com/search-console
5. Add property using URL prefix:
   https://jibonjr5426-cmd.github.io/Jr-games/
6. Verify ownership using the HTML tag method:
   - Search Console gives you a meta verification tag.
   - Copy the exact tag into <head> of index.html.
   - Commit/publish, then click Verify.
7. In Search Console > Sitemaps, submit: sitemap.xml
8. Use URL Inspection for the homepage and click Request Indexing.

Important:
- SEO cannot guarantee a first-place ranking or a particular display name.
- Google decides when and whether to index/update a page.
- Do not invent or copy a verification token. Use the exact token shown in your own Search Console account.
- Keep the site public and make sure it returns HTTP 200.
